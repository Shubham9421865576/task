<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'oop_pdo_crud');
define('DB_USER', 'root');
define('DB_PASS', '');
